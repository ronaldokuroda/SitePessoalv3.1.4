function download(){
   onclick=window.location.href='./assets/arquivos/CurriculoRonaldoKuroda.pdf';

}